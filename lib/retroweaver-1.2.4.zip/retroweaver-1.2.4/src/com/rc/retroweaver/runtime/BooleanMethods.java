package com.rc.retroweaver.runtime;

public final class BooleanMethods {

	public static boolean parseBoolean(String s) {
		return (s != null) && s.equalsIgnoreCase("true");
	}

	public static int compareTo(Boolean b1, Boolean b2) {
		return (b1.booleanValue() == b2.booleanValue())?0:(b1.booleanValue()?1:-1);
	}

}
