All project information can be found at http://code.google.com/p/jvorbiscomment/ and the "Project Home Page" linked from there.

Please report any bugs immediately so I can fix them immediately.
